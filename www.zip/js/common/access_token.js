(function() {
	'use strict';

	angular
		.module('redacao.common', [])
		.factory('AccessToken', AccessToken);

	function AccessToken() {
		var service = {
		};

		return service;
	}
})();
